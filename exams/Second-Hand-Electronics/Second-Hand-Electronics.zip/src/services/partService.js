const { search } = require('../controllers/homeController')
const Part = require('../models/Part')





//? Create a new Crypto
exports.create = async (partData) => {
    const newPart = await Part.create(partData)
    return newPart
}

//? Catalog render 
exports.getAll = () => Part.find().populate('owner')  //? Сложихме populate за да вземeм owner.username в catalog.hbs

//? Delete photo
exports.delete = (partId) => Part.findByIdAndDelete(partId)


//? Edit photo
exports.edit = (partId, photoData) => Part.findByIdAndUpdate({_id:partId}, {$set:photoData},{runValidators:true}).populate('owner')


//? Details render
exports.getOne = (partId) => Part.findById(partId).populate('owner') //? Сложихме populate за да вземem owner.username в catalog.hbs



//? OneUser -за гласувалите users
exports.getOneUser= (partId) => Part.findById(partId).populate('votes')


//? Vote game
exports.voted = (partId, userId) => Part.findByIdAndUpdate(partId, { $push: { buyingList: userId } }).populate('owner')

//? Search parts
exports.searchParts = (search, type) => Part.find({ name: { $regex: search, $options: 'i' }, type: { $regex: type } })

